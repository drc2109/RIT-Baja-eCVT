/*
 * Controller_P7_MSD26370_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Controller_P7_MSD26370".
 *
 * Model version              : 5.16
 * Simulink Coder version : 25.2 (R2025b) 28-Jul-2025
 * C source code generated on : Tue Apr  7 14:10:51 2026
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#ifndef Controller_P7_MSD26370_types_h_
#define Controller_P7_MSD26370_types_h_

/* Parameters (default storage) */
typedef struct P_Controller_P7_MSD26370_T_ P_Controller_P7_MSD26370_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_Controller_P7_MSD2637_T RT_MODEL_Controller_P7_MSD263_T;

#endif                                 /* Controller_P7_MSD26370_types_h_ */
